Running the executable will print all the answers. 
