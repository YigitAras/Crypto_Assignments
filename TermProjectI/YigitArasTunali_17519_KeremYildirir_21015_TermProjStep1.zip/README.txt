Project group members are Kerem Yıldırır 21015 and Yiğit Aras Tunalı 17519

Extra Dependencies: pycryptodome
